﻿namespace Server.Dtos;

public class WebLoginDto
{
    public string Email { get; set; }

    public string Password { get; set; }
}
