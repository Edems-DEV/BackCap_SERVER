﻿namespace Server.ParamClasses;

public class PathsDto
{
    public int Id_Config { get; set; }

    public string Path { get; set; }
}
