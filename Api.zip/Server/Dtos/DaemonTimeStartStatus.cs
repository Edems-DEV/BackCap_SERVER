﻿namespace Server.Dtos;

public class DaemonTimeStartStatus
{
    public short Status { get; set; }

    public DateTime Time_start { get; set; }
}
